var saldo = 1000.00

while (true){
  console.log("Menu:")
  console.log("1 - Saque")
  console.log("2 - Saldo")
  console.log("3 - Deposito")
  console.log("4 - Sair")
  
  var opcao = Number(prompt("Escolha a operação."))
  
  if (opcao == 1){
    var valorSaque = Number(prompt("Digite o valor de saque."))
    if (valorSaque > 0 && valorSaque <= saldo){
      saldo = saldo - valorSaque
      console.log("O saque foi realizado com sucesso.")
    }
  }
  else if (opcao == 2){
  console.log(`O seu saldo é de: R$ ${saldo.toFixed(2)}`)
  }
  else if (opcao == 3){
    var deposito = Number(prompt("Digite o valor a ser depositado."))
    if (deposito > 0){
      saldo = saldo + deposito
      console.log("O deposito foi realizado com sucesso.")
    }
  }
  else if (opcao == 4) {
    break
  }

  else {
    console.log("Escolha inválida.")
  }
}