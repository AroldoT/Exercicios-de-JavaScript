
var num1 = Number(prompt("Digite um numero."));

if (num1 % 2 == 0 && num1 / 2 >= 0){
    console.log(`O número é par e positivo.`)
}
else {
    console.log(`O número não atende`)
}