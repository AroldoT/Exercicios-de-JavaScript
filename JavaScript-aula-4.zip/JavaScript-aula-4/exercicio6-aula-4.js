let word = prompt("Digite uma palavra")
let palavra = ''

for (letra of word) {
    palavra = letra + palavra
}

if (word == palavra) {
    console.log(`A palavra ${word} é um palindromo`)
}
else {
    console.log(`A palavra ${word}não é um palídromo`)
}