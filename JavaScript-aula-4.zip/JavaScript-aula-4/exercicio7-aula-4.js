let word = prompt("Digite uma palavra")
let count = 0
for (letra of word) {
    if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
        count++
    }
}

console.log(count)