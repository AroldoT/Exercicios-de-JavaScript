var num 
var total = 0

while (num != 0){
  num = Number(prompt("Digite um numero."))
  total = total + num
};

console.log(total)