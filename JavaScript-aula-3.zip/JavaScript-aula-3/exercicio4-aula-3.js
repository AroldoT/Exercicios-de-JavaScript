var nome
var senha
while (nome == senha) {
  nome = prompt("Digite o nome de usuario.")
  senha = prompt("Digite a senha do usuario.")
  if (nome == senha) {
    console.log("A senha não pode ser igual ao nome de usuario.")
  }
}