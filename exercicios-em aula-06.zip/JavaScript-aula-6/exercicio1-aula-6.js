function contarLetras (nome) {
    let count = 0
    for (item of nome) {
        switch (item){
            case ('a'):
                count++;
                break
            case ('e'):
                count++;
                break
            case ('i'):
                count++;
                break
            case ('o'):
                count++;
                break
            case ('u'):
                count++;
                break
            case ('A'):
                count++;
                break
            case ('E'):
                count++;
                break
            case ('I'):
                count++;
                break
            case ('O'):
                count++;
                break
            case ('U'):
                count++;
                break
        };
    };
    console.log(`O numero de vogais é: ${count}`)
};

const nome = prompt("digite uma palavra")
console.log(contarLetras(nome));
