let lista = []
let par = []
let impar = []

for (i = 1; i <= 20; i++) {
    lista.push(i);
    if (i % 2 == 0){
        par.push(i)
    }
    else {
        impar.push(i)
    }
}

console.log(lista)
console.log(par)
console.log(impar)