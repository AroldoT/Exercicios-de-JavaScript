const multiplicar = (num1, num2) => {
  return num1 * num2
}

console.log(multiplicar(27, 30))