let word = prompt("Digite uma palavra")

for (letra of word) {
    if (letra == 'a' || letra == 'e' || letra == 'i' || letra =='o' || letra == 'u'){
        continue
    }
    else {
        console.log(letra)
    }
}