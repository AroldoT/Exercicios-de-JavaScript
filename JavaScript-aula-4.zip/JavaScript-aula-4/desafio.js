function getRandomArbitrary(min, max) {
    return Math.random() * (6 - 1) + 1;
  };

while (true) {
    let opcao = Number(prompt("Digite 1 para jogar e 0 para parar."))
    if (opcao == 1) {

        let num = prompt("Escolha par ou impar")
        let randomNum
        randomNum = getRandomArbitrary().toFixed(0);
        
        if (randomNum % 2 == 0) {
            if (num == 'par'){
                console.log("Você ganhou")
            }
            else {
                console.log("Você não ganhou")
            }
        }
        else {
            if (num == 'impar') {
                console.log("Você ganhou")
            }
            else {
                console.log("Você não ganhou")
            }
        };
    }
    else if (opcao == 0) {
        break
    }
    else {
        continue
    };
};