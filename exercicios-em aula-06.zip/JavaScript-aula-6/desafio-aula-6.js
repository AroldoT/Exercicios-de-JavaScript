function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const corpo = document.querySelector('body')
const resultado = document.createElement('p')
function jogar(){

    let randomNumber = getRandomNumber(2, 12);
    let a = randomNumber;

    if (randomNumber == 7 || randomNumber == 11) {
        console.log("Você ganhou, parabens.")
        resultado.textContent = 'Você ganhou, parabens. :)'
        resultado.style.color = '#00ff00'
        corpo.appendChild(resultado)
    }
    else if (a == 4 || a == 5 || a == 6 || a == 8 || a == 9 || a == 10){
        while (true){
            let b = randomNumber;
            
            if (b == a){
                console.log("Você ganhou, parabens.")
                resultado.textContent = 'Você ganhou, parabens. :)'
                resultado.style.color = '#00ff00'
                corpo.appendChild(resultado)
                break
            }
            else if (b == 7) {
                console.log("Você perdeu :( ")
                resultado.textContent = 'Você perdeu :( '
                resultado.style.color = 'red'
                corpo.appendChild(resultado)
                break
            };
        }
    }
    else if (a == 2 || a == 3 || a== 12) {
        console.log("Você perdeu :( ")
        resultado.textContent = 'Você perdeu :( '
        resultado.style.color = 'red'
        corpo.appendChild(resultado)
    };
};

const esconder = document.querySelector('.container')
function tutorial() {
        if (esconder.style.display == 'none') {
            esconder.style.display = 'block'
        }
        else if (esconder.style.display == 'block') {
            esconder.style.display = 'none'
        };
};