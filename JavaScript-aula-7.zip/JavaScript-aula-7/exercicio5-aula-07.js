
function aplicarFuncao (resultado) {
  let x = 20;
  const somarX = y => y + x;
  return somarX(resultado)
}

console.log(aplicarFuncao(7))