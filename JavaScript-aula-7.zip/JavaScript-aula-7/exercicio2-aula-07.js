let count = 0
const contar = nome => {
    const palavra = nome.toLowerCase();
    for(item of palavra) {
        if (item == 'a' || item == 'e' || item == 'i' || item == 'o' || item == 'u') {
            count++
        }
    }
    console.log()
}

const palavra = document.querySelector('input')
const texto = document.querySelector('p')
texto.innerHTML = `O número de vogais é: ${count}`

contar(palavra)