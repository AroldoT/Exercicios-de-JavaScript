var count = 0;
var nota = 0;
var opcao = 0;
var total = 0;

while (opcao == 0){
  nota = Number(prompt("Digite sua nota"))
  if (nota >= 0 && nota <= 10){
    total = total + nota
    count = count + 1
  }
  else {
    console.log("Valor errado.")
  }
  opcao = Number(prompt("Escolha se deseja continuar"))
};
  var media = total / count;
  console.log(media);
