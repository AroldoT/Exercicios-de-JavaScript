let num1 = Number(prompt("Digite um número"))
let num2 = Number(prompt("Digite um número"))

const somar = function(a, b) {
    return a + b
}

console.log(somar(num1, num2))