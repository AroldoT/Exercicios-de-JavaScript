let crime = []

console.log("Responda as perguntas com 's' ou 'n' para sim ou não respectivamente.")
console.log("Telefonoupara a vítima?")
console.log("Esteveno local do crime?")
console.log("Mora perto da vítima?")
console.log("Devia para a vítima?")
console.log("Já trabalhou com a vítima?")

for (i = 0; i < 5; i++) {
    let pergunta = prompt("")
    crime.push(pergunta)
};

let count = 0

for (resposta of crime) {
    if (resposta == 's') {
       count++ 
    }
};

if (count < 2) {
    console.log("Inocente")
}
else if (count == 2) {
    console.log("Suspeita")
}
else if (count > 2 && count <= 4) {
    console.log("Cúmplice")
}
else if (count == 5) {
    console.log("Cupaldo")
};