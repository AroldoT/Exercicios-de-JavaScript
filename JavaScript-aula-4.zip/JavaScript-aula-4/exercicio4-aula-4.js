let num = Number(prompt("Digite um numero"));
let primo = 0;

for (let i = 1; i <= num; i++) {
    
    if (num % i == 0) {
        primo++;
    };
};

if (primo == 2) {
    console.log("O numero é primo")
}
else {
    console.log("O numero não é primo")
}