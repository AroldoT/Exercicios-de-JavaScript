let soma, count;
count = 1;
soma = 0;
while (count <= 50) {
  soma = soma + count
  count++
}

console.log(soma)

