const calculadora = function(opcao) {
    const num1 = Number(prompt("Digite um número"))
    const num2 = Number(prompt("Digite um número"))

    if (opcao == '+') {
            return num1 + num2
    }
    else if (opcao == '-') {
            return num1 - num2
    }
    else if (opcao == '*') {
            return num1 * num2
        }
    else if (opcao == '/') {
            return num1 / num2
    };

};

console.log('Digite + para somar')
console.log('Digite - para subtrair')
console.log('Digite * para multiplicar')
console.log('Digite / para dividir')
const opcao = prompt('Escolha uma operação matemática')

console.log(calculadora(opcao))