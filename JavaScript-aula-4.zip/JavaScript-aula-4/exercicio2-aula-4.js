let num = Number(prompt("Digite um numero"))

for (let i = 1; i < 11; i++) {
    console.log(`${num}x${i}=${num*i}`)
}