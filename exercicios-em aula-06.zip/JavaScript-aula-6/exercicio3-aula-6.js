let raio = Number(prompt("Digite o raio da circunferencia"))

function calcularP (raio) { 
    const perimetro = 2 * 3.14 * raio
    return perimetro
};

function calcularA (raio) {
    const area = 3.14 * raio * raio
    return area
};

console.log(`O perimetro da circunferencia é: ${calcularP(raio).toFixed(2)}`)
console.log(`A area da circunferencia é: ${calcularA(raio).toFixed(2)}`)