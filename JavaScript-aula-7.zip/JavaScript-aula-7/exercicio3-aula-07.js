function converterTemperatura(celsius) {
  return ((celsius * 9/5) + 32);
};

const celsiusT = converterTemperatura(100);

function callBack(fahrenheit) {
  console.log(`O valor é ${fahrenheit}°F`)
};

callBack(celsiusT);

