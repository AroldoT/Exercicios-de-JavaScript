// function somar(x, y) {
//     return x + y
// }

// console.log(somar(3, 5))

// function calcularAreaTerreno(largura, comprimento){
//     let area = largura * comprimento
//     return area
// }

// console.log(calcularAreaTerreno(4, 8))
//================================================================
function multiplicar(num, num2) {
    return num*num2
};

const corpo = document.querySelector('form');
corpo.addEventListener('submit', (e) => {
    e.preventDefault();
    //document.getElementById('demo').innerHTML = multiplicar(3, 2)
    
    const numero1 = document.querySelector('#demo1').value;
    const numero2 = document.querySelector('#demo2').value;
    let tela = document.createElement('p');
    corpo.appendChild(tela);
    tela.textContent = `O resultado é: ${multiplicar(numero1, numero2)}`;
});
//===============================================================

