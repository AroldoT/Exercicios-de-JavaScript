let lista = [];
let num
let total = 0

for (i = 0; i < 4; i++) {
    num = Number(prompt("Digite a nota do aluno"))
    lista.push(num)
};

for (item of lista) {
    total = total + item
}

console.log(lista)
console.log(total / lista.length)