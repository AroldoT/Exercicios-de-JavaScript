function primo (num) {
    let count = 0
    for (i = 1; i <= num; i++){
        if (num % i == 0) {
            count++
        };
    };
    console.log(count)
    if (count == 2) {
        return `O número ${num} é primo`
    }
    else {
        return `O número ${num} não é primo`
    };
};
const num = Number(prompt("Digite um número"))
console.log(primo(num))