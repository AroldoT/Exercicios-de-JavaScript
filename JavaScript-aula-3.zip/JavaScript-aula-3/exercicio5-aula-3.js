let ida, count, total, media;
count = 0;
media = 0;
while (count < 5) {
  ida = Number(prompt("Digite sua idade."))
  if (ida > 0){
  total = total + ida;
  count++
  }
}
if (media >= 0 && media <= 25){
  console.log("A media da turma é jovem.")
}
else if (media >= 26 && media <= 60){
  console.log("A media da turma é adulta.")
}
else if (media > 60){
  console.log("A media da turma é idosa.")
}