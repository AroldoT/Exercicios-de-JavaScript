
var letra = prompt("Digite uma letra.")

                                            
switch(letra){
    case `a`:
        console.log(`É uma vogal`)
        break
    case `A`:
        console.log(`É uma vogal`)
        break

    case `e`: 
        console.log(`É uma vogal`)
        break
    case `E`:
        console.log(`É uma vogal`)
        break

    case `i`:
        console.log(`É uma vogal`)
        break
    case `I`:
        console.log(`É uma vogal`)
        break

    case `o`:
        console.log(`É uma vogal`)
        break
    case `O`:
        console.log(`É uma vogal`)
        break

    case `u`: 
        console.log(`É uma vogal`)
        break
    case `U`:
        console.log(`É uma vogal`)
        break

    default:
        console.log(`Não é uma vogal`)
        break
};
