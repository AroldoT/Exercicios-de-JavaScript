const nome = 'asd'
const password = '1234'
function autenticarUsuario(nomeU, senha, funcao) {
  if (nomeU == nome && senha == password) {
    
  }
}

