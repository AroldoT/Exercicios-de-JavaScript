for (let i = 3; i <= 30; i += 3) {
    console.log(i)
}

for (let i = 1; i <= 30; i++) {
    console.log(i)
}