let lista1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

let lista2 = [];

for (item of lista1) {
    lista2.unshift(item)
};

console.log(lista1)
console.log(lista2)