function cubo(num) {
  return num ** 3;
};

const valor = cubo(10);

function callBack(resultado) {
  console.log(`O resultado é ${resultado}`)
  // resultado(num)
};

callBack(valor);