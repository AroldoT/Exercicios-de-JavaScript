function quadrado (num) {
    let total = 0
    total = num * num
    return total
};

let num = Number(prompt("Digite um número"))
console.log(`O quadrado do ${num} é: ${quadrado(num)}`)