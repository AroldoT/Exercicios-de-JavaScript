var num = Number(prompt("Digite um numer."))

while (num > 0){
  console.log(num)
  num--
}

if (num == 0){
  console.log(num)
}
