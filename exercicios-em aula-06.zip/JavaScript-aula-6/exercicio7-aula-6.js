function valorPagamento(conta, dias) {
    let total = 0
    if (dias == 0) {
        total = conta
        return total
    }
    else if (dias > 0) {
        total = conta + (conta * 0.03) + (conta * (dias * 0.001))
        return total
    };
};
let boleto
let total = 0
let count = 0

while (boleto != 0) {
    boleto = Number(prompt("Digite o valor da conta"))
    if (boleto == 0) {
        console.log(`O valor total de contas pagas é: ${total.toFixed(2)}`)
        console.log(`A quantidade de contas pagas é: ${count}`)
        break
    }
    let atrasos = Number(prompt("Digite a quantidade de dias em atraso"))
    if (boleto > 0) {
        total = valorPagamento(boleto, atrasos) + total
        count = count + 1
        }
    else if (boleto < 0) {
        continue
    };
};