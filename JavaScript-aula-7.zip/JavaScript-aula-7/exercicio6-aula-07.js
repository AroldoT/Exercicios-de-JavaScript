function operacaoMatematica( funcao, num1, num2) {
  if (funcao == somar) {
    const somar = (num1, num2) => num1 + num2;
  }
  const subtrair = (num1, num2) => num1 + num2;
  const multiplicar = (num1, num2) => num1 + num2;
  const dividir = (num1, num2) => num1 + num2;
  //return funcao(num1, num2);
}

console.log(operacaoMatematica(somar, 21, 5))

// ão entendi de como fazer