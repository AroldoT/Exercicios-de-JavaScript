let num = Number(prompt("Digite um numero"))

if (num > 0){
    for (let i = num; i!= -1; i--) {
        console.log(i);
    }
}